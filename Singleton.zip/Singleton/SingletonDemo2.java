import java.io.*;
import java.util.Properties;

class SingletonPattern{
	public static SingletonPattern sp = null;
	public Properties pr = null;

	private SingletonPattern(){}
	
	public Properties getProperties(){
		return pr;	
	}
	
	public void setProperties(Properties pr){
		this.pr = pr;	
	}

	public static synchronized SingletonPattern getSingletonObject(){
		if(sp == null){
			sp = new SingletonPattern();
			Properties pr1 = new Properties();
			try{
				pr1.load(new FileInputStream("PropertyFile.properties"));
				sp.setProperties(pr1);			
			}catch(Exception e){ e.printStackTrace(); }
			return sp;		
		}
		return sp;
	}
	
	public Object clone() throws CloneNotSupportedException{
		
		throw new CloneNotSupportedException();		
	}	
}

class SingletonDemo2{
	public static void main(String args[]){
		SingletonPattern sp = SingletonPattern.getSingletonObject();
		System.out.println("Company: "+sp.getProperties().get("company"));
	  	System.out.println("Employee: "+sp.getProperties().get("employee"));
		System.out.println("Email: "+sp.getProperties().get("email"));
		System.out.println("Mobno: "+sp.getProperties().get("mobno"));	
		
		//SingletonPattern sp1 = new SingletonPattern();
		//Above line compile time error: SingletonPattern() has private access in SingletonPattern

		//SingletonPattern sp2 = (SingletonPattern) sp.clone();
		/*Above line compile time exception:  unreported exception CloneNotSupportedException; must be caught or declared to 			be thrown */

	}
}

/*Output
-----------------------------
Company: MarutiTechlabs
Employee: Gautam
Email: gautampatel199516@gmail.com
Mobno: 9904039135
*/
