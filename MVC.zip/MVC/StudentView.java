//View - Presentation Logic
package MVC;

class StudentView 
{
   public void printStudentDetails(String studentName, String studentRollNo){
      System.out.println("-----------------------------");
      System.out.println("Roll No: " + studentRollNo);
	  System.out.println("Name: " + studentName);
   }
}