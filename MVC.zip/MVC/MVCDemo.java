/*MVC
----------------------------------------------
Model-	It contains Business Logic (Getter/Setter Method)
View-	It contains Presentation Logic
Controller-	It controls the data flow into model object and updates the view whenever data changes. 
*/

package MVC;
class MVCDemo {
   public static void main(String[] args) {

      //Initialize
      Student model  = InitializeData();

      //Create a view object
      StudentView view = new StudentView();

      StudentController controller = new StudentController(model, view);

      controller.updateView();

      //update model data
      controller.setStudentName("Sachin");

      controller.updateView();
   }

   private static Student InitializeData(){
      Student student = new Student();
      student.setName("Gautam");
      student.setRollNo("06");
      return student;
   }
}

/*Output
-----------------------------------------
-----------------------------
Roll No: 06
Name: Gautam
-----------------------------
Roll No: 06
Name: Sachin

*/