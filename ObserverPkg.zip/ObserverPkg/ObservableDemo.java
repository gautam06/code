package ObserverPkg;

import java.util.Observable;

class ObservableDemo extends Observable
{
    private String weather;
	
    public ObservableDemo(String weather)
    {
		this.weather = weather;
    }
    public String getWeather()
    {
        return weather;
    }
    public void setWeather(String weather)
    {
        this.weather = weather;
        setChanged();
        notifyObservers();
    }
}
