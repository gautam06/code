/*Observer
--------------------------------------------------
one-to-many relationship between objects 
if one object is modified, its depenedent objects are to be notified automatically
Example of weather -> if its' change than notify
the class which implements interface Observable will call 
	-setChanged();
    -notifyObservers();
the class which implements interface Observer should have implemted method
	-void update(Observable, Object)
*/
package ObserverPkg;

import java.util.Observable;
import java.util.Observer;

class ObserverExample implements Observer
{
    private ObservableDemo weatherUpdate ;
	
    @Override
    public void update(Observable observable, Object arg)
    {
            weatherUpdate = (ObservableDemo) observable;
            System.out.println("Weather Report Live: "+weatherUpdate.getWeather());
    }
    public static void main(String[] args)
    {
            ObservableDemo observable = new ObservableDemo(null);
            ObserverExample observer = new ObserverExample();
            observable.addObserver(observer);
            observable.setWeather("It's Sunny...");
            observable.setWeather("It's Cloudy...");
            observable.setWeather("It's Raining Heavily!");
            observable.setWeather("It's Stormy!!!");
    }
}

/*Output
----------------------------------
javac *.java
cd ..
java ObserverPkg.ObserverExample
-------------------------------------------
Weather Report Live: It's Sunny...
Weather Report Live: It's Cloudy...
Weather Report Live: It's Raining Heavily!
Weather Report Live: It's Stormy!!!
*/