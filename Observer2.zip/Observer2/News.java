import java.util.*;
class News   extends Observable
{

String msg = "Today's weather is sunny !" ;
String news_item[]={"Reliance Jio said it is ready with a car connected device!" , "India wins the Series against England." , "Behind Rupee ban, Modi's plan to remake Indians."};

public void setNews()
{

     for(String s : news_item)
	{
		msg = s ;
		setChanged();
		notifyObservers();

		try
		{
			Thread.sleep(4000);
		}
	    catch(Exception e){ }
	}
}

public String getNews(){ return msg ; }

}

/*Output
----------------------------------------------
Welcome News is :Today's weather is sunny !
News Updated  : Reliance Jio said it is ready with a car connected device!
News Updated  : India wins the Series against England.
News Updated  : Behind Rupee ban, Modi's plan to remake Indians.

*/