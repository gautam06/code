import java.util.*;
 
class NewsDisplay implements Observer 
{
	public void setNews(String s){
	 	System.out.println("Welcome News is :"+s);
	}

	public void update(Observable ob , Object o){
		News n= (News)ob ;
		System.out.println("News Updated  : "+ n.getNews());
	}
}

