import java.util.*;

class TestObserver
{
	public static void main(String[] args)
	{
		News n = new News();
		NewsDisplay nd = new NewsDisplay() ;


		nd.setNews( n.getNews());


		n.addObserver(nd) ;

		//NewsDisplay nd1 = new NewsDisplay() ;
		//NewsDisplay nd2 = new NewsDisplay() ;

		//n.addObserver(nd1) ;

		//n.addObserver(nd2) ;


		n.setNews();

	}

}
