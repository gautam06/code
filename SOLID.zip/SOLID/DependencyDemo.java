/*
Dependency Inversion
-------------------------------------
"Depend on abstractions, not on concretions"
In this example there are two type of database connectivity possible MySql / Oracle
if it changes than connectivity string no need to changes at many places 

Classes -> MySQLConnection, OracleConnection <- Password Reminder will use it
*/
interface DBConnectionInterface {
	public String getDriver();
	public String getConURL();
	public String getUserName();
	public String getPassword();
}

class MySQLConnection implements DBConnectionInterface {
	private String DRIVER = "mysql.jdbc.Driver";
	private String CONNECTION_URL="jdbc:mysql://localhost:3306/sonoo"; 
	private String USERNAME = "gautam";
	private String PASSWORD = "123786";    
	
	public String getDriver(){
		return DRIVER;
	}
	public String getConURL(){
		return CONNECTION_URL;	
	}
	public String getUserName(){
		return USERNAME;	
	}
	public String getPassword(){
		return PASSWORD;	
	}
}

class OracleConnection implements DBConnectionInterface{
	private String DRIVER="oracle.jdbc.driver.OracleDriver";
	private String CONNECTION_URL="jdbc:oracle:thin:@localhost:1521:xe";
	private String USERNAME="system";
	private String PASSWORD="oracle";

	public String getDriver(){
		return DRIVER;
	}
	public String getConURL(){
		return CONNECTION_URL;	
	}
	public String getUserName(){
		return USERNAME;	
	}
	public String getPassword(){
		return PASSWORD;	
	}
}

class PasswordReminder {
    private DBConnectionInterface dbConnection;
    private String DbConString;

    public void construct(DBConnectionInterface dbConnection) {
        this.dbConnection = dbConnection;
	System.out.println("Database Driver: "+dbConnection.getDriver());
	System.out.println("Database Connection URL: "+dbConnection.getConURL());
	System.out.println("Database Username: "+dbConnection.getUserName());
	System.out.println("Database Password: "+dbConnection.getPassword());		    
   }
} 

class DependencyDemo{
	public static void main(String args[]){
		PasswordReminder pr = new PasswordReminder();		
		pr.construct(new MySQLConnection());
		
		//suppose if connection change then
		System.out.println("\n-------------------------------------------\n");		
		System.out.println("If connection chage to oracle then no need to modify");		
		pr.construct(new OracleConnection());	
	}
}

/*Output
------------------------------------------
Database Driver: mysql.jdbc.Driver
Database Connection URL: jdbc:mysql://localhost:3306/sonoo
Database Username: gautam
Database Password: 123786

-------------------------------------------

If connection chage to oracle then no need to modify
Database Driver: oracle.jdbc.driver.OracleDriver
Database Connection URL: jdbc:oracle:thin:@localhost:1521:xe
Database Username: system
Database Password: oracle

*/
