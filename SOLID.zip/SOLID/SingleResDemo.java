/*
Single Responsibility Principle
------------------------------------
One class should have only single responsibility
In this example separate classes for Employee Details
Calculate Salary & Saving records.
*/

import java.util.Scanner;
import java.util.ArrayList;-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
gautam
Enter Employee Designation: 
Trainee
Enter Employee basic: 
20000
Net Salary: 21400.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
Sarvam
Enter Employee Designation: 
Trainee
Enter Employee basic: 
21000
Net Salary: 22470.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
Ram
Enter Employee Designation: 
Employee
Enter Employee basic: 
25000
Net Salary: 26750.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 5
Invalid choice
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 0
Have a nice day! bye

class Salary{
	public static double calculateSalary(double basic,float da,float hra,float it){
		return (basic + (basic*da/100) + (basic*hra/100) - (basic*it/100));
	}
}
class Save{
	private static ArrayList<Employee> empAl = new ArrayList<>() ;
	private Save(){}
	
	public static ArrayList<Employee> getArrayListObject(){
		return empAl;	
	}
	public static void saveEmployeeData(Employee e){
		empAl.add(e);
	}
}
class Employee{
	String ename;
	String desg;
	double salary;
	

	public Employee(){}

	public void displayEmployeeDetails(){
		echo("Employee Name: "+ename);
		echo("Employee Desg: "+desg);
		echo("Employee Salary: "+salary);	
	}
	
	public void echo(String s){
		System.out.println(s);	
	}

	public void enterEmployeeDetails(){
		Scanner sc = new Scanner(System.in);
		
		echo("Enter Employee Name: ");
		ename = sc.nextLine();
		echo("Enter Employee Designation: ");
		desg = sc.nextLine();
		echo("Enter Employee basic: ");
		double basic = Double.parseDouble(sc.nextLine());

		float da = 6;
		float hra = 4;
		float it = 3;

		salary = Salary.calculateSalary(basic,da,hra,it);

		System.out.println("Net Salary: "+salary);
	 
	}

}
class SingleResDemo{
	public static void main(String args[]){	
		
		ArrayList<Employee> eal = Save.getArrayListObject();
		Scanner sc = new Scanner(System.in);
		int ch=0;
		do{
			System.out.println("-: Menu :-");
			System.out.println("------------------------------");
			System.out.println("1 Insert New Employee Data");
			System.out.println("2 Display All Employee Data");
			System.out.println("0 Exit");
			System.out.println("------------------------------");

			System.out.print("Enter your choice: ");
			ch = sc.nextInt();
			
			switch(ch){
				case 1:
					Employee e = new Employee();
					e.enterEmployeeDetails();
					Save.saveEmployeeData(e);
					break;
				case 2:
					for(Employee obj:eal){	
						obj.displayEmployeeDetails();
				   	 }			
				case 0:
					System.out.println("Have a nice day! bye");
					break;					
				default:
					System.out.println("Invalid choice");
					break;
			}			
		}while(ch!=0);
					
		  
 	}  
}

/*Output
----------------------------------------
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
gautam
Enter Employee Designation: 
Trainee
Enter Employee basic: 
20000
Net Salary: 21400.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
Sarvam
Enter Employee Designation: 
Trainee
Enter Employee basic: 
21000
Net Salary: 22470.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 1
Enter Employee Name: 
Ram
Enter Employee Designation: 
Employee
Enter Employee basic: 
25000
Net Salary: 26750.0
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 5
Invalid choice
-: Menu :-
------------------------------
1 Insert New Employee Data
2 Display All Employee Data
0 Exit
------------------------------
Enter your choice: 0
Have a nice day! bye

*/
