/*
Liskov Substitution Principle
----------------------------------------
Every subclass/derived should be substituable for their base/parent class
Here Cat Cow extednds abstract class Animal which should define the mwthod makeNoise() & eat()
in case of MuteMouse it is not possible to make no sound.
*/

abstract class Animal{
	public abstract void makeNoise();
	public abstract void eat();
} 

class Cat extends Animal{
	public void makeNoise(){
		System.out.println("Cat: Sounds meow");	
	}
	public void eat(){
		System.out.println("Cat: eats meat, vegetables");	
	}
}

class Cow extends Animal{
	public void makeNoise(){
		System.out.println("Cow: Sounds Moo");	
	}
	public void eat(){
		System.out.println("Cow: eats vegetables");	
	}
}

/* 

// Exceptional Code
class MuteMouse implements Animal{
	public void makeNoise() throws Exception{
		//do not sound		
		throws new Exception();
	}
	public void eat(){
		System.out.println("eats meat, vegetables");
	}
}
*/

class LiskovPrincipleDemo{
	public static void main(String args[]) throws Exception{
		Animal a = new Cat();
		a.makeNoise();
		a.eat();
		
		a = new Cow();
		a.makeNoise();
		a.eat();
/* Exceptional Code		
		a = new MuteMouse();
		a.makeNoise();
		a.eat();	
*/
	}
}
