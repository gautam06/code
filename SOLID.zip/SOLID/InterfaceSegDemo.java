/*Interface Segregation
-----------------------------------------
-A client should never be forced to implement an interface that it doesn’t use or clients shouldn’t be forced to depend on methods they do not use.

Here the interfaces are separated for Animals like run jump fly and swim
the needed class will implement interface.
*/
interface Run{
	void run();
}
interface Jump{
	void jump();
}
interface Fly{
	void fly();
}
interface Swim{
	void swim();
}

class Peacock implements Run, Jump, Fly{
	public void run(){
		System.out.println("Peacock can run");	
	}
	public void jump(){
		System.out.println("Peacock can jump");
	}
	public void fly(){
		System.out.println("Peacock can fly");
	}
}

class Elephant implements Run, Swim{
	public void run(){
		System.out.println("Elephant can run");	
	}	
	public void swim(){
		System.out.println("Elephant can swim");
	}
} 


class InterfaceSegDemo{
	public static void main(String args[]){
		Peacock p = new Peacock();
		p.run();
		p.jump();
		p.fly();
		System.out.println("--------------------------------------");
		Elephant e = new Elephant();
		e.run();
		e.swim();
	}
}

/*Output
--------------------------------------------
Peacock can run
Peacock can jump
Peacock can fly
--------------------------------------
Elephant can run
Elephant can swim

*/
